import socket
import ssl

# Define the target host and ports to scan
target_host = "10.44.16.176lll"
target_ports = [80, 443, 22, 21, 23]

# Create a socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Define a function to scan for open ports
def scan_ports(host, ports):
    for port in ports:
        try:
            # Try to connect to the target host on the current port
            s.connect((host, port))
            print(f"[+] Port {port} is open")
            check_security(host, port)
            s.close() # close the socket after the check is done
        except:
            # If the connection fails, the port is closed or filtered
            print(f"[-] Port {port} is closed or filtered")

# Define a function to check the security of open ports
def check_security(host, port):
    if port == 443:
        try:
            # Try to create an SSL context
            context = ssl.create_default_context()
            # Try to connect to the target host on the current port using SSL
            conn = context.wrap_socket(s, server_hostname=host)
            print(f"[+] Port {port} is using SSL/TLS")
        except ssl.SSLError:
            print(f"[-] Port {port} is not using SSL/TLS")
    elif port == 22:
        try:
            # Try to send a simple command to check if the port is SSH
            s.send(b'SSH-2.0-OpenSSH_7.2p2 Ubuntu-4ubuntu2.8\r\n')
            data = s.recv(1024)
            if b"SSH" in data:
                print(f"[+] Port {port} is SSH")
            else:
                print(f"[-] Port {port} is not SSH")
        except:
            pass
    else:
        print(f"[?] Security of port {port} cannot be determined")

# Call the function to scan for open ports
scan_ports(target_host, target_ports)