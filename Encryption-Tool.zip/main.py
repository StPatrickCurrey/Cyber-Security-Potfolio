def encryption(text, shift):
    result = ''
    for i in range(len(text)):
        char = text[i]
        if char.isupper():
            result += chr((ord(char) - 65 + shift) % 26 + 65)
        elif char.islower():
            result += chr((ord(char) - 97 + shift) % 26 + 97)
        else:
            result += char
    return result

text = "hello"
print(encryption(text, 3))



"""def encryption (text, shift):
  result = ''
  for i in range (len(text)):
    char = text[i]
    if char.isupper():
      result += chr((ord(char) - 65 + shift) % 26 + 65)

    if char.islower():
      result += chr((ord(char) - 97 + shift) %26 + 97)

    else:
      result += char

  return result



    